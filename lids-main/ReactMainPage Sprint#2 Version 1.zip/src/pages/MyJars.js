import { useState, useEffect } from "react";
import { useQuery, gql } from "@apollo/client";
import { useMutation } from "@apollo/client";
import { useCookies } from "react-cookie";
import { LOAD_JARS } from './gql/Jars'
import NewJarPopup from "./components/NewJarPopup";
import LineImage2 from './images/BlackLineBorder2.png'
import JarDetailsPopup from "./JarDetailsPopup";

function MyJars() {
    const [ newJarPopupState, setNewJarPopupState ] = useState(false);
    const [ newJarDetailsPopup, setNewJarDetailsPopup ] = useState(false);
    const [ cookies, setCookie ] = useCookies(['session']);
    const [ jsonData, setJsonData ] = useState("");
    //const { error, loading, data } = useQuery(LOAD_JARS)
    //const [jars, setJars] = useState([]);
     /*   useEffect(() => {
            if (data){
                setJars(data.LoadJars)
            }
        }, [data]); */

       

    function togglePopup() {
        setNewJarPopupState(!newJarPopupState);
    }
    function toggleDetailsPopup() {
        setNewJarDetailsPopup(!newJarDetailsPopup);
    }
 
    return (
        <>
         <img src={LineImage2} className="imageline2" alt = "logo"/>
         <button class="create-button" onClick={togglePopup}>+</button>       
         <NewJarPopup popupOpen={newJarPopupState} setPopupState={{togglePopup}} />
         <p className = "debug-jar" onClick={toggleDetailsPopup}>Debug</p>
         <JarDetailsPopup popupOpenJar={newJarDetailsPopup} setPopupStateJar={{toggleDetailsPopup}} />
        </>
        
    );
}

export default MyJars;