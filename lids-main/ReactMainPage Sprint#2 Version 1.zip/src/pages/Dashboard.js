import { NavLink } from 'react-router-dom';
import JarButtonLogo from './images/JarButtonLogo.png'
import AccountButtonLogo from './images/AccountButtonLogo.png'
import FriendsButtonLogo from './images/FriendsButtonLogo.png'
import SettingsButtonLogo from './images/SettingsButtonLogo.png'

const Dashboard = () => {
    return (
   <>
   <img src={JarButtonLogo} className="jarbuttonlogo" alt= "logo"/>
   <img src={AccountButtonLogo} className= "accountbuttonlogo" alt= "logo"/>
   <img src={FriendsButtonLogo} className="friendsbuttonlogo" alt= "logo"/>
   <img src={SettingsButtonLogo} className="settingsbuttonlogo" alt="logo"/>
   <button class="dashboardjar-button"><NavLink to="/my-jars">Jars</NavLink></button>
   <button class="dashboardaccount-button"><NavLink to ="/account">Account</NavLink></button>
   <button class="dashboardfriends-button">Friends</button>
   <button class="dashboardsettings-button"><NavLink to ="/settings">Settings</NavLink></button>
   </>
   
    
)
};

export default Dashboard;