const Account = () => {
    return <>
        <p className="account-info">Account Info</p>
        <p className = "account-name">Name:</p>
        <p className = "account-username">Username:</p>
        <p className ="account-phone">Phone Number:</p>
        <p className = "account-email">Email Address:</p>   
        <p className = "account-password">Password</p>
        <p className = "account-currentpassword">Current Password:</p>
        <p className = "account-social">Social Profiles</p>       
        <p className = "social-facebook">Facebook:</p>
        <p className = "social-twitter">Twitter:</p>
        <p className = "social-instagram">Instagram:</p>
        <p className = "social-tiktok">Tiktok:</p>
        <p className = "social-tumblr">Tumblr:</p>
        </>;
}

export default Account;