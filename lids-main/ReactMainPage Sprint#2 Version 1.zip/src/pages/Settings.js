const Settings = () => {

    return <>
        <p className = "settings-tag">Settings</p>
        <p className = "settings-experimental">Experimental</p>
        <p className ="settings-darkmode">Dark Mode:</p>


    
    </>




    



}

export default Settings