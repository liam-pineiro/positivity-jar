import { useNavigate } from "react-router-dom";
import { useState } from "react";

function JarDetailsPopup({ popupOpenJar, setPopupStateJar }) {
    const [details, setDetails] = useState("");

    const navigate = useNavigate();

    function onChange(event) { 
        var newValue = event.target.value;

        setDetails(newValue);
    }

    if (popupOpenJar) {
        return (
            <div className="jar-details-popup">
                <h className ="debugjar-details">Debug Jar</h>
                <button className="add-entry">Add Entry</button>    
                <button className="detele-entry">Delete Entry</button>
            </div>
        )
    }
}

export default JarDetailsPopup;