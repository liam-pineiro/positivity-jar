import { Outlet } from "react-router-dom";
import "./App.css";
import Navbar from "./pages/components/NavBar";
import Jarlogo from './pages/images/JarReactTest2.png'
import LineImage from './pages/images/BlackLineBorder.png'

import React from 'react'
import ReactDOM from 'react-dom/client'
import { ApolloClient, InMemoryCache, ApolloProvider, HttpLink, from} from '@apollo/client';

import { setContext } from '@apollo/client/link/context';
import { createHttpLink } from '@apollo/client';
import { onError } from "@apollo/client/link/error";

const App = () => {

   /* const client = new ApolloClient({
      cache: new InMemoryCache(),
      uri: ""
    }) */
  
  
    return (
        <>
          <img src={Jarlogo} className="imagejar" alt="logo" />          
          <img src={LineImage} className="imageline" alt="logo"/>
            <Navbar />
                
            <Outlet />
        </>
    );
};

export default App;